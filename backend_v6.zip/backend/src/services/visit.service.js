import { v4 as uuid } from "uuid";
import {
  getCurrentCityByCase,
  getCityPlaces,
  insertCityPlace,
  getAllPlaceTypes,
} from "../repositories/visit.repo.js";
import { getStepOptions } from "../repositories/route.repo.js";
import { getLastTravelLogForStep } from "../repositories/travel_log.repo.js";
import { countRevealedCluesInCity } from "../repositories/clue.repo.js";
import pool from "../config/database.js";
import { consumeActionTime, estimateTravelMinutes, getCaseTimeSummary } from "./time.service.js";

const VISIT_MINUTES = 30;

export async function visitCurrentCityService(caseId) {
  if (!caseId) {
    throw new Error("CaseId não informado");
  }

  // 1️⃣ Cidade atual
  // getCurrentCityByCase já retorna lat/lon corretos agora
  const city = await getCurrentCityByCase(caseId);
  if (!city) {
    throw new Error("Cidade atual não encontrada");
  }

  // Ajuste para retorno consistente com o esperado pelo front (useGame.ts espera geo_coordinates)
  // Mas o repo agora retorna lat/lon planos. Vamos manter plano e ajustar o mapping no final ou no useGame.ts?
  // O useGame.ts espera: geo_coordinates: { x, y } (do endpoint)
  // Então aqui montamos o objeto de resposta.
  // city já tem city.lat e city.lon.

  // 2️⃣ Verificar se já existem locais definidos
  const existingPlaces = await getCityPlaces(caseId, city.city_id);
  
  // Lógica de Places (mantida)
  let places = existingPlaces;
  if (places.length < 3) {
    // 3️⃣ Sortear locais (primeira visita)
    const allPlaces = await getAllPlaceTypes();
    if (allPlaces.length < 3) throw new Error("Tipos de locais insuficientes");
    const selected = allPlaces.slice(0, 3);
    const clueMap = ["NEXT_LOCATION", "NEXT_LOCATION", "VILLAIN"];
    
    for (let i = 0; i < 3; i++) {
      const placeId = uuid();
      await insertCityPlace({
        id: placeId, caseId, cityId: city.city_id, placeTypeId: selected[i].id, clueType: clueMap[i],
      });
      places.push({
        id: placeId, place_type_id: selected[i].id, name: selected[i].name,
        interaction_style: selected[i].interaction_style, clue_type: clueMap[i],
      });
    }
    // Consome tempo APENAS na primeira geração (chegada)
    await consumeActionTime({ caseId, minutes: VISIT_MINUTES, timezone: "America/Sao_Paulo" });
  }

  // Obter Time State atualizado
  const timeState = await getCaseTimeSummary({ caseId });

  // 4️⃣ Obter opções de viagem
  // REGRA: Só mostrar opções se houver pelo menos 1 pista revelada NESTA cidade
  let travelOptions = [];
  const revealedCount = await countRevealedCluesInCity(caseId, city.city_id);

  if (revealedCount > 0) {
    const stepOptions = await getStepOptions(caseId, city.step_order);
    
    if (stepOptions?.options?.length > 0) {
      const ids = stepOptions.options;
      const placeholders = ids.map(() => "?").join(",");
      const [rows] = await pool.query(
        `SELECT c.id, c.name, ST_Y(c.geo_coordinates) as lat, ST_X(c.geo_coordinates) as lon, co.name as country_name, c.description_prompt as description_prompt, c.image_url as image_url 
         FROM cities c 
         JOIN countries co ON co.id = c.country_id 
         WHERE c.id IN (${placeholders})`,
        ids
      );

      // Calcular estimativas em paralelo
      travelOptions = await Promise.all(rows.map(async (r) => {
        // Agora r.lat e r.lon são números reais
        
        // Estimativa de tempo
        let travelTime = 0;
        try {
          travelTime = await estimateTravelMinutes({ 
            fromCityId: city.city_id, 
            toCityId: r.id, 
            caseId 
          });
        } catch (e) {
          console.warn(`Erro ao calcular tempo para cidade ${r.id}:`, e.message);
        }

        const hours = Math.floor(travelTime / 60);
        const mins = travelTime % 60;
        const formatted = hours > 0 ? `${hours}h${mins > 0 ? ` ${mins}m` : ''}` : `${mins}m`;

        return {
          id: r.id,
          name: r.name,
          country_name: r.country_name,
          latitude: r.lat,
          longitude: r.lon,
          travel_time_minutes: travelTime,
          travel_time_formatted: formatted,
          description_prompt: r.description_prompt,
          image_url: r.image_url
        };
      }));
    }
  }

  return {
    city: {
        ...city,
        // Adicionar geo_coordinates para compatibilidade com useGame.ts se necessário,
        // ou garantir que o useGame mapeie lat/lon direto.
        // O useGame.ts v8 espera: geo_coordinates: { x: number; y: number };
        geo_coordinates: { x: city.lon, y: city.lat }
    },
    places,
    travelOptions, // Será vazio se revealedCount === 0
    timeState
  };
}

export async function visitCityService(caseId, requestedCityId = null) {
  // Mantendo a lógica de fallback/debug
  if (!caseId) throw new Error("CaseId não informado");

  const current = await getCurrentCityByCase(caseId);
  if (!current) throw new Error("Cidade atual não encontrada");

  let targetCityId = current.city_id;
  const optionsMeta = await getStepOptions(caseId, current.step_order);
  const allowed = Array.isArray(optionsMeta?.options) ? optionsMeta.options : [];

  if (requestedCityId) {
    if (!allowed.includes(requestedCityId)) throw new Error("Cidade inválida para visita neste passo");
    targetCityId = requestedCityId;
  } else {
    const lastLog = await getLastTravelLogForStep(caseId, current.step_order);
    if (lastLog && lastLog.success === 0 && allowed.includes(lastLog.to_city_id)) {
      targetCityId = lastLog.to_city_id;
    }
  }

  // Garantir places
  let places = await getCityPlaces(caseId, targetCityId);
  if (places.length === 0) {
     const [placeTypes] = await pool.execute(`SELECT id, name, interaction_style FROM place_types ORDER BY RAND()`);
    const chosen = placeTypes.slice(0, 3);
    const clueTypes = ["VILLAIN", "VILLAIN", "VILLAIN"];
    for (let i = 0; i < chosen.length; i++) {
       await insertCityPlace({ id: uuid(), caseId, cityId: targetCityId, placeTypeId: chosen[i].id, clueType: clueTypes[i]});
    }
    places = await getCityPlaces(caseId, targetCityId);
    await consumeActionTime({ caseId, minutes: VISIT_MINUTES, timezone: "America/Sao_Paulo" });
  }

  const timeState = await getCaseTimeSummary({ caseId });

  // Travel Options - MESMA REGRA: Só mostrar se houver pistas reveladas
  let travelOptions = [];
  const revealedCount = await countRevealedCluesInCity(caseId, targetCityId);

  if (revealedCount > 0 && optionsMeta?.options?.length > 0) {
      const ids = optionsMeta.options;
      const placeholders = ids.map(() => "?").join(",");
      const [rows] = await pool.query(
        `SELECT c.id, c.name, ST_Y(c.geo_coordinates) as lat, ST_X(c.geo_coordinates) as lon, co.name as country_name, c.description_prompt as description_prompt, c.image_url as image_url 
         FROM cities c JOIN countries co ON co.id = c.country_id 
         WHERE c.id IN (${placeholders})`, ids
      );
      
      travelOptions = await Promise.all(rows.map(async (r) => {
          let travelTime = 0;
          try {
            travelTime = await estimateTravelMinutes({ fromCityId: current.city_id, toCityId: r.id, caseId });
          } catch {}

          const hours = Math.floor(travelTime / 60);
          return {
            id: r.id,
            name: r.name,
            country_name: r.country_name,
            latitude: r.lat,
            longitude: r.lon,
            travel_time_minutes: travelTime,
            travel_time_formatted: `${hours}h`,
            description_prompt: r.description_prompt,
            image_url: r.image_url
          };
      }));
  }

  let targetCityData = { city_id: targetCityId, step_order: current.step_order };
  if (targetCityId === current.city_id) {
    targetCityData = { 
        ...targetCityData, 
        city_name: current.city_name, 
        country_name: current.country_name,
        geo_coordinates: { x: current.lon, y: current.lat } // Repassar coords
    };
  } else {
    // Buscar target city com geo correto
    const [rows] = await pool.query(`SELECT c.name as city_name, ST_Y(c.geo_coordinates) as lat, ST_X(c.geo_coordinates) as lon, co.name as country_name, c.description_prompt as description_prompt, c.image_url as image_url FROM cities c JOIN countries co ON co.id = c.country_id WHERE c.id = ?`, [targetCityId]);
    if (rows[0]) targetCityData = { 
        ...targetCityData, 
        ...rows[0],
        geo_coordinates: { x: rows[0].lon, y: rows[0].lat }
    };
  }

  return {
    city: targetCityData,
    places,
    travelOptions,
    timeState
  };
}
