export const AI_INTENT = {
  NPC_DIALOGUE: 'npc_dialogue',
  CLUE_TEXT: 'CLUE_TEXT',
  CITY_NARRATION: 'city_narration',
  VILLAIN_FINAL_DIALOGUE: 'villain_final_dialogue'
};
