-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `villain_templates`
--

DROP TABLE IF EXISTS `villain_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `villain_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `specialty` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favorite_regions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `threat_level` tinyint DEFAULT NULL,
  `is_iconic` tinyint(1) NOT NULL DEFAULT '0',
  `sex` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hobby` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hair_color` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other` text COLLATE utf8mb4_unicode_ci,
  `danger_level` tinyint DEFAULT '1',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `villain_templates`
--

LOCK TABLES `villain_templates` WRITE;
/*!40000 ALTER TABLE `villain_templates` DISABLE KEYS */;
INSERT INTO `villain_templates` VALUES (1,'suspect_carlos_monaco','Carlos Monaco',NULL,NULL,NULL,NULL,NULL,0,'male','Art Dealer','High-stakes poker','black','black sports car','cicatriz discreta perto da sobrancelha direita','ligado a leilões ilegais e falsificação de arte',3,1),(2,'suspect_elena_raven','Elena Raven',NULL,NULL,NULL,NULL,NULL,0,'female','Data Analyst','Urban photography','dark brown','motorcycle','tatuagem de corvo no pulso esquerdo','especialista em vazamento de dados confidenciais',4,1),(3,'suspect_otto_valen','Otto Valen',NULL,NULL,NULL,NULL,NULL,0,'male','Logistics Manager','Marathon running','blond','white van','sempre usa relógios digitais enormes','suspeito de coordenar rotas de fuga da V.I.L.E.',2,1),(4,'suspect_mira_caledonia','Mira Caledonia',NULL,NULL,NULL,NULL,NULL,0,'female','Historian','Collecting rare coins','red','compact car','óculos de armação grossa e lenços coloridos','obcecada por artefatos históricos raros',3,1),(5,'suspect_jonas_oberon','Jonas Oberon',NULL,NULL,NULL,NULL,NULL,0,'male','Security Consultant','Chess','grey','sedan','andar calmo, sempre de luvas','usa conhecimento de segurança para explorar falhas',4,1),(6,'suspect_ayumi_kato','Ayumi Kato',NULL,NULL,NULL,NULL,NULL,0,'female','Cybersecurity Engineer','Retro videogames','black','electric scooter','fone de ouvido sempre pendurado no pescoço','já trabalhou protegendo bancos que agora são alvo da V.I.L.E.',4,1),(7,'suspect_rafael_silva','Rafael Silva',NULL,NULL,NULL,NULL,NULL,0,'male','Documentary Filmmaker','Street art','brown','old hatchback','anda com câmera analógica pendurada','usa filmagens como cobertura para mapear rotas de fuga',2,1),(8,'suspect_helena_morozov','Helena Morozov',NULL,NULL,NULL,NULL,NULL,0,'female','Cryptographer','Classical piano','black','dark sedan','luva de couro na mão esquerda','reconhecida por quebrar cifras governamentais em tempo recorde',5,1),(9,'suspect_liam_o_connor','Liam O\'Connor',NULL,NULL,NULL,NULL,NULL,0,'male','Pilot','Rock climbing','auburn','private plane','cicatriz visível no queixo','costuma pilotar rotas não oficiais pelo mundo',3,1),(10,'suspect_samira_nassar','Samira Nassar',NULL,NULL,NULL,NULL,NULL,0,'female','Art Curator','Restoration of old books','dark brown','luxury coupe','anel de pedra verde chamativo','move obras de arte entre coleções privadas sem muitos registros oficiais',3,1);
/*!40000 ALTER TABLE `villain_templates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
