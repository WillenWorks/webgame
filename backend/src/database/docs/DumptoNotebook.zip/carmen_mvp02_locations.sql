-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'city',
  `country` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `continent` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_hint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_hint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `landmark_hint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag_hint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fun_fact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'monaco_city','Monaco','city','Monaco',NULL,NULL,NULL,NULL,NULL,NULL,'Europe','Pequeno principado famoso por cassinos e corridas de F1.'),(2,'paris','Paris','city','France',NULL,NULL,NULL,NULL,NULL,NULL,'Europe','Capital francesa, conhecida pela Torre Eiffel e museus de arte.'),(3,'london','London','city','United Kingdom',NULL,NULL,NULL,NULL,NULL,NULL,'Europe','Centro financeiro e cultural, com clima eternamente confuso.'),(4,'rome','Rome','city','Italy',NULL,NULL,NULL,NULL,NULL,NULL,'Europe','Cidade histórica repleta de ruínas romanas e arte renascentista.'),(5,'berlin','Berlin','city','Germany',NULL,NULL,NULL,NULL,NULL,NULL,'Europe','Capital alemã, mistura de história pesada e cena alternativa.'),(6,'new_york','New York','city','United States',NULL,NULL,NULL,NULL,NULL,NULL,'North America','Cidade que nunca dorme, cheia de oportunidades e sirenes.'),(7,'tokyo','Tokyo','city','Japan',NULL,NULL,NULL,NULL,NULL,NULL,'Asia','Metrópole de neon, tecnologia e tradições bem preservadas.'),(8,'sao_paulo','São Paulo','city','Brazil',NULL,NULL,NULL,NULL,NULL,NULL,'South America','Cidade gigante, caótica e criativa, com trânsito lendário.'),(9,'cairo','Cairo','city','Egypt',NULL,NULL,NULL,NULL,NULL,NULL,'Africa','Ponto de acesso às pirâmides e ao Nilo.'),(10,'sydney','Sydney','city','Australia',NULL,NULL,NULL,NULL,NULL,NULL,'Oceania','Cidade costeira famosa pela Opera House e praias.');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
