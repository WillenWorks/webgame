-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_step_npcs`
--

DROP TABLE IF EXISTS `case_step_npcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_step_npcs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `step_order` int NOT NULL,
  `archetype` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allegiance` enum('agent','neutral','villain') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neutral',
  `attitude` enum('friendly','neutral','hostile') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'neutral',
  `dialogue_high_reputation` text COLLATE utf8mb4_unicode_ci,
  `dialogue_neutral_reputation` text COLLATE utf8mb4_unicode_ci,
  `dialogue_low_reputation` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_case_step_npcs_case_step` (`case_id`,`step_order`),
  CONSTRAINT `fk_case_step_npcs_case` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_step_npcs`
--

LOCK TABLES `case_step_npcs` WRITE;
/*!40000 ALTER TABLE `case_step_npcs` DISABLE KEYS */;
INSERT INTO `case_step_npcs` VALUES (1,24,1,'Artista de rua','neutral','friendly','Ah, você é o famoso agente! Sempre ouvi sobre suas incríveis investigações. O que posso fazer para ajudar?','Oi, você está aqui para ver os murais? Eles têm histórias incríveis.','Você? Não pode ser o agente de que todos falam. O que você quer aqui?','2025-12-03 10:49:36'),(2,24,2,'Funcionário de museu / biblioteca','agent','friendly','É uma honra conhecer você! O que procura? Posso ajudá-lo a encontrar informações sobre arte contemporânea.','Bem-vindo à biblioteca. O que você gostaria de saber?','Você realmente deveria procurar por outra pessoa. Não sei se posso ajudar.','2025-12-03 10:49:36'),(3,24,3,'Informante underground','villain','hostile','Você é o famoso agente? O que você quer? Não tenho tempo para brincadeiras.','Ah, um agente. O que você está fazendo aqui?','Ha! Você? Não vale a pena me fazer perder meu tempo.','2025-12-03 10:49:36'),(4,25,1,'Dono de café/bar','neutral','friendly','Ah, o famoso agente! Ouvi histórias sobre você. O que posso fazer para ajudar na sua busca?','Olá! Você parece ser um viajante. O que traz você a este café?','Você é um agente? Não me faça rir. O que você quer aqui?','2025-12-03 11:22:51'),(5,25,2,'Funcionário de museu / biblioteca','agent','friendly','Você é uma lenda! O que posso fazer para ajudar um agente tão respeitado?','Ah, um visitante curioso. Como posso ajudar?','Você? O que faz aqui? Não tenho tempo para suas perguntas.','2025-12-03 11:22:51'),(6,25,3,'Funcionário de museu / biblioteca','neutral','neutral','Oh, é você! Sua fama precede você. O que deseja saber?','Bem-vindo. O que você procura na biblioteca?','Hum, mais um curioso. O que você quer?','2025-12-03 11:22:51'),(7,25,4,'Dono de café/bar','agent','friendly','Ah, o grande agente! Ouvi rumores sobre a sua busca. Posso ajudar?','Você está atrás de algo específico? Posso ajudar.','Você de novo? O que quer agora?','2025-12-03 11:22:51'),(8,25,5,'Informante underground','villain','hostile','Você é uma pessoa difícil de ignorar. Mas não tenho informações para você.','Quem é você? O que quer saber?','Não tenho tempo para você. Vá embora.','2025-12-03 11:22:51'),(9,26,1,'Funcionário de museu / biblioteca','agent','friendly','Ah, você é o renomado agente da ACME! Sua fama o precede, estamos ansiosos para ver como resolverá este caso.','Olá, agente. O que traz você aqui? Ouvi rumores, mas nada confirmado.','Hmm, outro agente da ACME? Não tenho muito tempo, mas é melhor você agir rápido.','2025-12-03 15:08:25'),(10,26,2,'Dono de café/bar','neutral','neutral','Ah, o famoso agente da ACME! O que posso fazer por você? Ouvi algumas histórias interessantes.','O que você procura aqui? Muitos vêm e vão, mas poucos ficam.','Olha, se você não é aqui para jogar, não sei o que está fazendo.','2025-12-03 15:08:25'),(11,26,3,'Funcionário de casa de câmbio / banco','neutral','friendly','Agente da ACME, que honra! Posso ajudar com informações sobre o leilão?','Ah, outro agente? O que você quer saber?','Olha, se você não tem nada de interessante a dizer, eu não tenho tempo para você.','2025-12-03 15:08:25'),(12,27,1,'Funcionário de museu / biblioteca','agent','friendly','É uma honra receber um agente tão respeitável como você! Tenho certeza de que encontrará pistas valiosas aqui.','Bem-vindo à biblioteca! Se precisar de ajuda, estou à disposição.','Você realmente acha que vai descobrir algo por aqui? Boa sorte!','2025-12-03 16:12:57'),(13,27,2,'Artista de rua','neutral','neutral','Ah, você é aquele agente famoso! Todos falam sobre suas investigações. O que traz você a Nova York?','Oi! O que você está procurando aqui na cidade?','Hmm, mais um agente perdido, não é? Espero que você tenha sorte.','2025-12-03 16:12:57'),(14,27,3,'Dono de café/bar','agent','friendly','Ah, o famoso agente! Seu trabalho é admirado por todos aqui. O que você precisa?','Bem-vindo ao meu café! Posso ajudar com alguma informação?','Você de novo? Espero que tenha algo interessante para me contar.','2025-12-03 16:12:57'),(15,27,4,'Funcionário de museu / biblioteca','agent','friendly','É um prazer ter você aqui! Conheço muitos segredos sobre as artes em Mônaco.','Olá! O que você gostaria de saber sobre as exposições?','Você realmente acha que vai encontrar algo interessante aqui?','2025-12-03 16:12:57'),(16,28,1,'Dono de café/bar','agent','friendly','Ah, você é o famoso agente da ACME! Ouvi falar muito sobre suas habilidades. Posso ajudar com qualquer informação que precisar.','Olá, agente. O que você precisa? As coisas estão bem agitadas por aqui.','Você novamente? Espero que tenha algo melhor para oferecer desta vez.','2025-12-03 17:57:35'),(17,28,2,'Funcionário de museu / biblioteca','neutral','neutral','Ah, o famoso agente! Conheço suas investigações. Se precisar de insights sobre arte moderna, estou à disposição.','Olá, agente. O que você está procurando por aqui?','Você de novo? Espero que esteja fazendo algo útil desta vez.','2025-12-03 17:57:35'),(18,28,3,'Informante underground','villain','hostile','Ah, o famoso agente da ACME! Espero que não venha me encrencar. Estou ocupado.','Oi. O que você quer? Estou ocupado.','Você? O que você quer? Não tenho tempo para você.','2025-12-03 17:57:35'),(19,28,4,'Guia local','agent','friendly','Ah, você é o respeitado agente! Conheço cada canto deste lugar e posso ajudar na sua busca.','Bem-vindo! O que você precisa saber sobre o Cairo?','Você? O que faz aqui? Não tenho tempo para você.','2025-12-03 17:57:35'),(20,29,1,'Funcionário de museu / biblioteca','agent','friendly','Ah, você é o famoso agente! Ouvi falar de suas habilidades em resolver casos complexos. Você pode ser a chave para isso também.','Olá! O que você está procurando? Há muitos rumores sobre essa galeria.','Quem é você mesmo? Espero que tenha um bom motivo para estar aqui.','2025-12-03 18:12:15'),(21,29,2,'Dono de café/bar','neutral','neutral','Ah, o agente de elite! O que posso fazer para ajudar? Ouvi que você tem um talento especial para encontrar o que foi perdido.','Quem diria que veria um agente por aqui. O que você precisa?','E aí, está perdido? Espero que não esteja por aqui só para fazer turismo.','2025-12-03 18:12:15'),(22,29,3,'Funcionário de museu / biblioteca','agent','friendly','Ah, o ilustre agente! Sua presença aqui é um sinal de que as coisas vão mudar. O que você precisa?','Bem-vindo ao museu. Posso ajudar com algo específico?','Você de novo? Espero que não venha apenas para olhar as obras sem propósito.','2025-12-03 18:12:15'),(23,29,4,'Comerciante de rua','villain','hostile','Ah, o famoso agente! O que você quer? Não vai encontrar nada aqui, eu conheço todos os meus clientes.','Você está procurando algo? Não tenho informações para você.','O que você quer? Sua fama não significa nada aqui.','2025-12-03 18:12:15');
/*!40000 ALTER TABLE `case_step_npcs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
