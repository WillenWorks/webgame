-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_villain_clues`
--

DROP TABLE IF EXISTS `case_villain_clues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_villain_clues` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `step_id` int DEFAULT NULL,
  `attribute_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clue_type` enum('villain','location') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'villain',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_clues_case` (`case_id`),
  KEY `fk_clues_step` (`step_id`),
  CONSTRAINT `fk_clues_case` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_clues_step` FOREIGN KEY (`step_id`) REFERENCES `case_steps` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_villain_clues`
--

LOCK TABLES `case_villain_clues` WRITE;
/*!40000 ALTER TABLE `case_villain_clues` DISABLE KEYS */;
INSERT INTO `case_villain_clues` VALUES (1,6,19,'hair_color','black','villain','2025-12-01 13:10:51'),(2,6,20,'occupation','Cryptographer','villain','2025-12-01 13:10:51'),(3,6,22,'hobby','Classical piano','villain','2025-12-01 13:10:51'),(4,7,23,'hair_color','auburn','villain','2025-12-01 13:56:13'),(5,7,24,'vehicle','private plane','villain','2025-12-01 13:56:13'),(6,7,25,'hobby','Rock climbing','villain','2025-12-01 13:56:13'),(7,7,26,'sex','male','villain','2025-12-01 13:56:13'),(8,8,29,'hobby','Chess','villain','2025-12-01 14:02:32'),(9,8,30,'vehicle','sedan','villain','2025-12-01 14:02:32'),(10,8,31,'hair_color','grey','villain','2025-12-01 14:02:32'),(11,8,32,'occupation','Security Consultant','villain','2025-12-01 14:02:32'),(12,9,33,'hair_color','dark brown','villain','2025-12-01 14:58:11'),(13,9,34,'hobby','Urban photography','villain','2025-12-01 14:58:11'),(14,9,35,'occupation','Data Analyst','villain','2025-12-01 14:58:11'),(15,9,37,'vehicle','motorcycle','villain','2025-12-01 14:58:11'),(16,10,39,'hobby','High-stakes poker','villain','2025-12-01 14:58:19'),(17,10,40,'vehicle','black sports car','villain','2025-12-01 14:58:19'),(18,10,42,'occupation','Art Dealer','villain','2025-12-01 14:58:19'),(19,11,43,'hair_color','black','villain','2025-12-01 14:58:30'),(20,11,44,'hobby','Retro videogames','villain','2025-12-01 14:58:30'),(21,11,45,'vehicle','electric scooter','villain','2025-12-01 14:58:30'),(22,11,47,'hobby','Retro videogames','villain','2025-12-01 14:58:30'),(23,23,95,'hair_color','black','villain','2025-12-03 11:59:19'),(24,23,95,'occupation','Cybersecurity Engineer','villain','2025-12-03 11:59:19'),(25,23,95,'hobby','Retro videogames','villain','2025-12-03 11:59:19'),(26,23,95,'vehicle','electric scooter','villain','2025-12-03 11:59:19'),(27,23,95,'feature','fone de ouvido sempre pendurado no pescoço','villain','2025-12-03 11:59:19'),(28,24,96,'hobby','Street art','villain','2025-12-03 13:49:36'),(29,24,96,'feature','anda com câmera analógica pendurada','villain','2025-12-03 13:49:36'),(30,24,97,'occupation','Documentary Filmmaker','villain','2025-12-03 13:49:36'),(31,24,97,'occupation','Documentary Filmmaker','villain','2025-12-03 13:49:36'),(32,24,98,'vehicle','old hatchback','villain','2025-12-03 13:49:36'),(33,24,98,'vehicle','old hatchback','villain','2025-12-03 13:49:36'),(34,25,99,'feature','luva de couro na mão esquerda','villain','2025-12-03 14:22:51'),(35,25,100,'occupation','Cryptographer','villain','2025-12-03 14:22:51'),(36,25,100,'hair_color','black','villain','2025-12-03 14:22:51'),(37,25,101,'feature','luva de couro na mão esquerda','villain','2025-12-03 14:22:51'),(38,25,102,'hobby','Classical piano','villain','2025-12-03 14:22:51'),(39,25,102,'hobby','Classical piano','villain','2025-12-03 14:22:51'),(40,25,103,'vehicle','dark sedan','villain','2025-12-03 14:22:51'),(41,25,103,'hobby','Classical piano','villain','2025-12-03 14:22:51'),(42,26,104,'occupation','Security Consultant','villain','2025-12-03 18:08:25'),(43,26,104,'occupation','Security Consultant','villain','2025-12-03 18:08:25'),(44,26,105,'feature','andar calmo, sempre de luvas','villain','2025-12-03 18:08:25'),(45,26,105,'feature','andar calmo, sempre de luvas','villain','2025-12-03 18:08:25'),(46,26,106,'hobby','Chess','villain','2025-12-03 18:08:25'),(47,26,106,'feature','andar calmo, sempre de luvas','villain','2025-12-03 18:08:25'),(48,27,107,'occupation','Art Curator','villain','2025-12-03 19:12:57'),(49,27,107,'hair_color','dark brown','villain','2025-12-03 19:12:57'),(50,27,108,'vehicle','luxury coupe','villain','2025-12-03 19:12:57'),(51,27,108,'feature','anel de pedra verde chamativo','villain','2025-12-03 19:12:57'),(52,27,109,'hobby','Restoration of old books','villain','2025-12-03 19:12:57'),(53,27,109,'hobby','Restoration of old books','villain','2025-12-03 19:12:57'),(54,27,110,'vehicle','luxury coupe','villain','2025-12-03 19:12:57'),(55,28,111,'occupation','Data Analyst','villain','2025-12-03 20:57:35'),(56,28,111,'hair_color','dark brown','villain','2025-12-03 20:57:35'),(57,28,112,'hobby','Urban photography','villain','2025-12-03 20:57:35'),(58,28,112,'occupation','Data Analyst','villain','2025-12-03 20:57:35'),(59,28,113,'vehicle','motorcycle','villain','2025-12-03 20:57:35'),(60,28,113,'feature','tatuagem de corvo no pulso esquerdo','villain','2025-12-03 20:57:35'),(61,28,114,'feature','tatuagem de corvo no pulso esquerdo','villain','2025-12-03 20:57:35'),(62,29,115,'hobby','Restoration of old books','villain','2025-12-03 21:12:15'),(63,29,116,'feature','anel de pedra verde chamativo','villain','2025-12-03 21:12:15'),(64,29,116,'occupation','Art Curator','villain','2025-12-03 21:12:15'),(65,29,117,'sex','female','villain','2025-12-03 21:12:15'),(66,29,117,'hair_color','dark brown','villain','2025-12-03 21:12:15'),(67,29,118,'feature','anel de pedra verde chamativo','villain','2025-12-03 21:12:15');
/*!40000 ALTER TABLE `case_villain_clues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
