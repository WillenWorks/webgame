-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agent_id` int NOT NULL,
  `villain_id` int DEFAULT NULL,
  `external_case_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'available',
  `difficulty` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'easy',
  `max_turns` int DEFAULT NULL,
  `score_earned` int DEFAULT NULL,
  `is_promotion_case` tinyint(1) NOT NULL DEFAULT '0',
  `villain_template_id` int DEFAULT NULL,
  `start_location_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `closed_at` timestamp NULL DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `villain_template_id` (`villain_template_id`),
  KEY `start_location_id` (`start_location_id`),
  KEY `idx_cases_villain_id` (`villain_id`),
  CONSTRAINT `cases_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`id`),
  CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`villain_template_id`) REFERENCES `villain_templates` (`id`),
  CONSTRAINT `cases_ibfk_3` FOREIGN KEY (`start_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `fk_cases_villain` FOREIGN KEY (`villain_id`) REFERENCES `villain_templates` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
INSERT INTO `cases` VALUES (1,1,NULL,NULL,'Caso preliminar: atividade suspeita em London','Relatório inicial indica movimentação suspeita ligada a Mira Caledonia em London. Este caso ainda não foi enriquecido pela IA.','solved','easy',NULL,NULL,0,4,3,'2025-11-29 19:57:18','2025-12-01 14:57:54','2025-12-01 14:57:54',NULL),(3,1,NULL,NULL,'O Mistério da Música Perdida','Um famoso código criptografado foi roubado e a única pista deixada foi uma partitura clássica. O agente deve seguir as pistas que levam até a habilidosa criptógrafa Helena Morozov, antes que ela escape com informações valiosas. O desafio está em decifrar as mensagens escondidas e encontrar a localização dela.','solved','easy',NULL,NULL,0,8,4,'2025-11-29 21:11:29','2025-12-01 14:46:38','2025-12-01 14:46:38',NULL),(6,1,NULL,NULL,'O Enigma da Música Perdida','Uma série de mensagens codificadas foram encontradas em um concerto de piano em Monaco. O agente deve decifrar as pistas que levam a uma famosa criptógrafa, com o objetivo de impedir um grande roubo de informações sensíveis.','solved','easy',NULL,NULL,0,8,9,'2025-12-01 13:10:51','2025-12-01 13:25:09','2025-12-01 13:25:09',NULL),(7,1,NULL,NULL,'Mistério dos Voos Não Registrados','Uma série de voos não oficiais tem chamado a atenção das autoridades em Mônaco. O agente deve investigar pistas que levam a um piloto misterioso, conhecido por suas rotas irregulares e um passado intrigante. O objetivo é descobrir sua identidade e impedir novos voos clandestinos.','solved','easy',NULL,NULL,0,9,3,'2025-12-01 13:56:13','2025-12-01 14:01:31','2025-12-01 14:01:31',NULL),(8,1,NULL,NULL,'A Jogada Perigosa','Um roubo audacioso de arte em Mônaco deixou a Interpol em alerta. O agente deve seguir pistas que revelam as intenções de um misterioso consultor de segurança enquanto ele tenta capturar as obras de arte desaparecidas.','solved','easy',NULL,NULL,0,5,7,'2025-12-01 14:02:32','2025-12-01 14:06:59','2025-12-01 14:06:59',NULL),(9,1,NULL,NULL,'Rastros de Dados em Mônaco','Uma série de vazamentos de dados confidenciais está afetando empresas em Mônaco. O agente deve investigar as pistas que levam a um especialista em dados, conhecida por sua habilidade em urban photography, enquanto navega por locais icônicos da cidade.','solved','easy',NULL,150,0,2,9,'2025-12-01 14:58:11','2025-12-02 19:13:41','2025-12-02 19:13:41',NULL),(10,1,NULL,NULL,'A Arte do Engano','O agente foi chamado para investigar uma série de leilões ilegais de arte que estão acontecendo em várias cidades. O objetivo é rastrear o responsável por essas atividades ilícitas e recuperar as obras de arte roubadas antes que desapareçam para sempre.','solved','easy',NULL,150,0,1,2,'2025-12-01 14:58:19','2025-12-02 19:13:31','2025-12-02 19:13:31',NULL),(11,1,NULL,NULL,'A Caçada Digital em Mônaco','Um roubo audacioso de dados em um banco em Mônaco deixou pistas que levam a uma especialista em segurança cibernética. O agente deve investigar os locais frequentados por Ayumi Kato e descobrir sua conexão com o crime antes que ela desapareça.','solved','easy',NULL,140,0,6,1,'2025-12-01 14:58:30','2025-12-02 19:12:39','2025-12-02 19:12:39',NULL),(14,1,3,NULL,'A Corrida pela Verdade em Paris','O agente foi enviado a Paris após relatos de atividades suspeitas envolvendo um misterioso gerente de logística. O objetivo é reunir informações que levem à captura de um notório vilão que está coordenando rotas de fuga da V.I.L.E.','solved','easy',NULL,150,0,NULL,NULL,'2025-12-02 19:29:15','2025-12-02 19:29:24','2025-12-02 19:29:24',NULL),(15,1,7,NULL,'Rastros de Câmera','Um valioso documentário foi roubado e você, um agente especial, precisa descobrir quem está por trás desse crime. Através de pistas deixadas em várias cidades, você deve rastrear o culpado antes que ele escape com o prêmio.','solved','easy',NULL,150,0,NULL,NULL,'2025-12-02 19:57:14','2025-12-02 19:58:06','2025-12-02 19:58:06',NULL),(16,1,6,NULL,'A Sombra do Cibercrime','Um importante banco em Londres sofreu um ataque cibernético, e todas as pistas levam a um misterioso engenheiro de segurança. O agente deve descobrir a identidade dessa figura obscura antes que mais crimes aconteçam.','solved','easy',NULL,150,0,NULL,NULL,'2025-12-02 19:58:21','2025-12-02 19:58:56','2025-12-02 19:58:56',NULL),(17,1,6,NULL,'A Rota da Invasão Digital','Um ataque cibernético em um banco em São Paulo levanta suspeitas de uma nova operação da V.I.L.E. O agente deve seguir pistas que o levarão a Ayumi Kato, uma engenheira de segurança cibernética com um passado misterioso. O objetivo é descobrir sua conexão com os crimes e impedi-la.','solved','medium',NULL,230,0,NULL,NULL,'2025-12-02 19:59:12','2025-12-02 20:10:38','2025-12-02 20:10:38',NULL),(18,1,7,NULL,'O Enigma da Arte Perdida em Mônaco','Um valioso documentário sobre street art desapareceu em Mônaco, e rumores dizem que Rafael Silva pode estar envolvido. Sua missão é rastrear suas pistas e descobrir suas intenções antes que ele escape novamente.','solved','medium',NULL,230,0,NULL,NULL,'2025-12-02 19:59:25','2025-12-02 20:10:46','2025-12-02 20:10:46',NULL),(19,1,10,NULL,'A Arte da Ilusão','O agente é chamado para investigar uma série de movimentações suspeitas de obras de arte em coleções privadas. As pistas levam a Samira Nassar, uma curadora de arte com fama questionável. O objetivo é descobrir suas intenções e impedir uma transação ilícita.','solved','medium',NULL,230,0,NULL,NULL,'2025-12-02 19:59:36','2025-12-02 20:10:52','2025-12-02 20:10:52',NULL),(20,1,8,NULL,'A Sinfonia do Código','Um código roubado está prestes a ser decifrado, e você deve encontrar Helena Morozov antes que ela conclua seu plano. Siga as pistas para descobrir onde ela se esconde e o que está tramando.','available','medium',NULL,NULL,0,NULL,NULL,'2025-12-02 20:11:08','2025-12-02 20:11:08',NULL,NULL),(21,1,4,NULL,'O Mistério das Moedas Raras','O agente é chamado para investigar o roubo de uma coleção inestimável de moedas raras em Paris. As pistas levam a uma figura excêntrica que pode estar ligada ao crime. O objetivo é descobrir a identidade do ladrão e recuperar as moedas antes que desapareçam para sempre.','available','medium',NULL,NULL,0,NULL,NULL,'2025-12-02 20:11:24','2025-12-02 20:11:24',NULL,NULL),(22,1,7,NULL,'A Câmera da Verdade','Um valioso artefato foi roubado durante um festival de street art em Londres. Seu objetivo é rastrear o ladrão, que utiliza filmagens como cobertura para suas atividades ilícitas. A pista inicial o levará a diferentes cidades ao redor do mundo.','available','medium',NULL,NULL,0,NULL,NULL,'2025-12-02 20:11:38','2025-12-02 20:11:38',NULL,NULL),(23,1,6,NULL,'A Rota do Cibercrime','O agente da ACME deve investigar um roubo de dados valiosos que levou a uma série de ataques cibernéticos. Com pistas que levam a vários países, o agente precisa descobrir a identidade do suspeito antes que ele consiga escapar novamente.','in_progress','easy',NULL,NULL,0,NULL,NULL,'2025-12-03 11:59:19','2025-12-03 13:46:11',NULL,NULL),(24,1,7,NULL,'Rastros pelo Mundo: O Enigma de Rafael Silva','O agente da ACME foi designado para investigar o desaparecimento de valiosos documentários de arte contemporânea. As pistas levam a um suspeito intrigante, Rafael Silva, um cineasta com uma peculiaridade: sua paixão por street art. O agente deve viajar e reunir informações cruciais para capturá-lo.','in_progress','easy',NULL,NULL,0,NULL,NULL,'2025-12-03 13:49:36','2025-12-03 13:50:58',NULL,NULL),(25,1,8,NULL,'A Sinfonia do Crime em Paris','O agente da ACME é chamado para investigar uma série de quebras de cifra em Paris, onde uma criptógrafa de renome parece estar envolvida. A missão é coletar pistas que levem a Helena Morozov, a principal suspeita, enquanto navega pela cultura parisiense.','available','easy',NULL,NULL,0,NULL,NULL,'2025-12-03 14:22:51','2025-12-03 14:22:51',NULL,NULL),(26,1,5,NULL,'O Jogo da Segurança em Paris','Um valioso artefato foi roubado de uma galeria em Paris, e você, um agente da ACME, deve descobrir a identidade do ladrão. As pistas o levarão a várias cidades e a um vilão astuto que utiliza suas habilidades de segurança para cometer delitos.','in_progress','easy',8,NULL,0,NULL,NULL,'2025-12-03 18:08:25','2025-12-03 18:10:30',NULL,NULL),(27,1,10,NULL,'A Arte do Crime em Cairo','Um valioso artefato foi roubado de uma galeria em Cairo, e é sua missão descobrir o paradeiro da criminosa Samira Nassar. Através de pistas que cruzam fronteiras, você deve desvendar os segredos que levam a seu próximo passo.','available','easy',NULL,NULL,0,NULL,NULL,'2025-12-03 19:12:57','2025-12-03 19:12:57',NULL,NULL),(28,1,2,NULL,'A Sombra do Corvo em Mônaco','Um valioso conjunto de dados foi vazado em Mônaco e a ACME suspeita que a analista de dados Elena Raven esteja por trás do crime. O agente deve seguir pistas entre diferentes países para descobrir a localização da vilã e recuperar as informações roubadas.','in_progress','easy',NULL,NULL,0,NULL,NULL,'2025-12-03 20:57:35','2025-12-03 20:59:00',NULL,NULL),(29,1,10,NULL,'O Mistério da Galeria Perdida','Uma valiosa coleção de arte desapareceu de uma galeria em Roma, e o agente está em busca de pistas para localizar a responsável. O caminho leva a várias cidades da Europa, onde a arte e a cultura se entrelaçam com o crime.','in_progress','easy',NULL,NULL,0,NULL,NULL,'2025-12-03 21:12:15','2025-12-03 21:12:23',NULL,NULL);
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
