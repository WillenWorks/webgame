-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_location_npcs`
--

DROP TABLE IF EXISTS `case_location_npcs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_location_npcs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `step_order` int NOT NULL,
  `location_id` int NOT NULL,
  `archetype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allegiance` enum('agent','neutral','villain') COLLATE utf8mb4_unicode_ci DEFAULT 'neutral',
  `attitude` enum('friendly','neutral','hostile') COLLATE utf8mb4_unicode_ci DEFAULT 'neutral',
  `dialogue_high_reputation` text COLLATE utf8mb4_unicode_ci,
  `dialogue_neutral_reputation` text COLLATE utf8mb4_unicode_ci,
  `dialogue_low_reputation` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `case_location_npcs_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `case_step_locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_location_npcs`
--

LOCK TABLES `case_location_npcs` WRITE;
/*!40000 ALTER TABLE `case_location_npcs` DISABLE KEYS */;
INSERT INTO `case_location_npcs` VALUES (1,28,1,46,'Dono de café/bar','agent','friendly','Ah, você é o famoso agente da ACME! Ouvi falar muito sobre suas habilidades. Posso ajudar com qualquer informação que precisar.','Olá, agente. O que você precisa? As coisas estão bem agitadas por aqui.','Você novamente? Espero que tenha algo melhor para oferecer desta vez.','2025-12-03 20:57:35'),(2,28,1,47,'Dono de café/bar','agent','friendly','Ah, você é o famoso agente da ACME! Ouvi falar muito sobre suas habilidades. Posso ajudar com qualquer informação que precisar.','Olá, agente. O que você precisa? As coisas estão bem agitadas por aqui.','Você novamente? Espero que tenha algo melhor para oferecer desta vez.','2025-12-03 20:57:35'),(3,28,1,48,'Dono de café/bar','agent','friendly','Ah, você é o famoso agente da ACME! Ouvi falar muito sobre suas habilidades. Posso ajudar com qualquer informação que precisar.','Olá, agente. O que você precisa? As coisas estão bem agitadas por aqui.','Você novamente? Espero que tenha algo melhor para oferecer desta vez.','2025-12-03 20:57:35'),(4,28,2,49,'Funcionário de museu / biblioteca','neutral','neutral','Ah, o famoso agente! Conheço suas investigações. Se precisar de insights sobre arte moderna, estou à disposição.','Olá, agente. O que você está procurando por aqui?','Você de novo? Espero que esteja fazendo algo útil desta vez.','2025-12-03 20:57:35'),(5,28,2,50,'Funcionário de museu / biblioteca','neutral','neutral','Ah, o famoso agente! Conheço suas investigações. Se precisar de insights sobre arte moderna, estou à disposição.','Olá, agente. O que você está procurando por aqui?','Você de novo? Espero que esteja fazendo algo útil desta vez.','2025-12-03 20:57:35'),(6,28,2,51,'Funcionário de museu / biblioteca','neutral','neutral','Ah, o famoso agente! Conheço suas investigações. Se precisar de insights sobre arte moderna, estou à disposição.','Olá, agente. O que você está procurando por aqui?','Você de novo? Espero que esteja fazendo algo útil desta vez.','2025-12-03 20:57:35'),(7,28,3,52,'Informante underground','villain','hostile','Ah, o famoso agente da ACME! Espero que não venha me encrencar. Estou ocupado.','Oi. O que você quer? Estou ocupado.','Você? O que você quer? Não tenho tempo para você.','2025-12-03 20:57:35'),(8,28,3,53,'Informante underground','villain','hostile','Ah, o famoso agente da ACME! Espero que não venha me encrencar. Estou ocupado.','Oi. O que você quer? Estou ocupado.','Você? O que você quer? Não tenho tempo para você.','2025-12-03 20:57:35'),(9,28,3,54,'Informante underground','villain','hostile','Ah, o famoso agente da ACME! Espero que não venha me encrencar. Estou ocupado.','Oi. O que você quer? Estou ocupado.','Você? O que você quer? Não tenho tempo para você.','2025-12-03 20:57:35'),(10,28,4,55,'Guia local','agent','friendly','Ah, você é o respeitado agente! Conheço cada canto deste lugar e posso ajudar na sua busca.','Bem-vindo! O que você precisa saber sobre o Cairo?','Você? O que faz aqui? Não tenho tempo para você.','2025-12-03 20:57:35'),(11,28,4,56,'Guia local','agent','friendly','Ah, você é o respeitado agente! Conheço cada canto deste lugar e posso ajudar na sua busca.','Bem-vindo! O que você precisa saber sobre o Cairo?','Você? O que faz aqui? Não tenho tempo para você.','2025-12-03 20:57:35'),(12,28,4,57,'Guia local','agent','friendly','Ah, você é o respeitado agente! Conheço cada canto deste lugar e posso ajudar na sua busca.','Bem-vindo! O que você precisa saber sobre o Cairo?','Você? O que faz aqui? Não tenho tempo para você.','2025-12-03 20:57:35'),(13,29,1,58,'Funcionário de museu / biblioteca','agent','friendly','Ah, você é o famoso agente! Ouvi falar de suas habilidades em resolver casos complexos. Você pode ser a chave para isso também.','Olá! O que você está procurando? Há muitos rumores sobre essa galeria.','Quem é você mesmo? Espero que tenha um bom motivo para estar aqui.','2025-12-03 21:12:15'),(14,29,1,59,'Funcionário de museu / biblioteca','agent','friendly','Ah, você é o famoso agente! Ouvi falar de suas habilidades em resolver casos complexos. Você pode ser a chave para isso também.','Olá! O que você está procurando? Há muitos rumores sobre essa galeria.','Quem é você mesmo? Espero que tenha um bom motivo para estar aqui.','2025-12-03 21:12:15'),(15,29,1,60,'Funcionário de museu / biblioteca','agent','friendly','Ah, você é o famoso agente! Ouvi falar de suas habilidades em resolver casos complexos. Você pode ser a chave para isso também.','Olá! O que você está procurando? Há muitos rumores sobre essa galeria.','Quem é você mesmo? Espero que tenha um bom motivo para estar aqui.','2025-12-03 21:12:15'),(16,29,2,61,'Dono de café/bar','neutral','neutral','Ah, o agente de elite! O que posso fazer para ajudar? Ouvi que você tem um talento especial para encontrar o que foi perdido.','Quem diria que veria um agente por aqui. O que você precisa?','E aí, está perdido? Espero que não esteja por aqui só para fazer turismo.','2025-12-03 21:12:15'),(17,29,2,62,'Dono de café/bar','neutral','neutral','Ah, o agente de elite! O que posso fazer para ajudar? Ouvi que você tem um talento especial para encontrar o que foi perdido.','Quem diria que veria um agente por aqui. O que você precisa?','E aí, está perdido? Espero que não esteja por aqui só para fazer turismo.','2025-12-03 21:12:15'),(18,29,2,63,'Dono de café/bar','neutral','neutral','Ah, o agente de elite! O que posso fazer para ajudar? Ouvi que você tem um talento especial para encontrar o que foi perdido.','Quem diria que veria um agente por aqui. O que você precisa?','E aí, está perdido? Espero que não esteja por aqui só para fazer turismo.','2025-12-03 21:12:15'),(19,29,3,64,'Funcionário de museu / biblioteca','agent','friendly','Ah, o ilustre agente! Sua presença aqui é um sinal de que as coisas vão mudar. O que você precisa?','Bem-vindo ao museu. Posso ajudar com algo específico?','Você de novo? Espero que não venha apenas para olhar as obras sem propósito.','2025-12-03 21:12:15'),(20,29,3,65,'Funcionário de museu / biblioteca','agent','friendly','Ah, o ilustre agente! Sua presença aqui é um sinal de que as coisas vão mudar. O que você precisa?','Bem-vindo ao museu. Posso ajudar com algo específico?','Você de novo? Espero que não venha apenas para olhar as obras sem propósito.','2025-12-03 21:12:15'),(21,29,3,66,'Funcionário de museu / biblioteca','agent','friendly','Ah, o ilustre agente! Sua presença aqui é um sinal de que as coisas vão mudar. O que você precisa?','Bem-vindo ao museu. Posso ajudar com algo específico?','Você de novo? Espero que não venha apenas para olhar as obras sem propósito.','2025-12-03 21:12:15'),(22,29,4,67,'Comerciante de rua','villain','hostile','Ah, o famoso agente! O que você quer? Não vai encontrar nada aqui, eu conheço todos os meus clientes.','Você está procurando algo? Não tenho informações para você.','O que você quer? Sua fama não significa nada aqui.','2025-12-03 21:12:15'),(23,29,4,68,'Comerciante de rua','villain','hostile','Ah, o famoso agente! O que você quer? Não vai encontrar nada aqui, eu conheço todos os meus clientes.','Você está procurando algo? Não tenho informações para você.','O que você quer? Sua fama não significa nada aqui.','2025-12-03 21:12:15'),(24,29,4,69,'Comerciante de rua','villain','hostile','Ah, o famoso agente! O que você quer? Não vai encontrar nada aqui, eu conheço todos os meus clientes.','Você está procurando algo? Não tenho informações para você.','O que você quer? Sua fama não significa nada aqui.','2025-12-03 21:12:15');
/*!40000 ALTER TABLE `case_location_npcs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
