-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_travel_options`
--

DROP TABLE IF EXISTS `case_travel_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_travel_options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `step_order` int NOT NULL,
  `country_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct_country` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_case_travel_case_step` (`case_id`,`step_order`),
  CONSTRAINT `fk_case_travel_options_case` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_travel_options`
--

LOCK TABLES `case_travel_options` WRITE;
/*!40000 ALTER TABLE `case_travel_options` DISABLE KEYS */;
INSERT INTO `case_travel_options` VALUES (1,24,1,'Germany',1,'2025-12-03 10:49:36'),(2,24,1,'France',0,'2025-12-03 10:49:36'),(3,24,1,'Italy',0,'2025-12-03 10:49:36'),(4,24,1,'Netherlands',0,'2025-12-03 10:49:36'),(5,24,2,'Italy',1,'2025-12-03 10:49:36'),(6,24,2,'Spain',0,'2025-12-03 10:49:36'),(7,24,2,'Portugal',0,'2025-12-03 10:49:36'),(8,24,2,'Greece',0,'2025-12-03 10:49:36'),(9,24,3,'France',1,'2025-12-03 10:49:36'),(10,24,3,'Belgium',0,'2025-12-03 10:49:36'),(11,24,3,'Switzerland',0,'2025-12-03 10:49:36'),(12,24,3,'Monaco',0,'2025-12-03 10:49:36'),(13,25,1,'France',1,'2025-12-03 11:22:51'),(14,25,1,'Belgium',0,'2025-12-03 11:22:51'),(15,25,1,'Italy',0,'2025-12-03 11:22:51'),(16,25,1,'Spain',0,'2025-12-03 11:22:51'),(17,25,2,'France',1,'2025-12-03 11:22:51'),(18,25,2,'Germany',0,'2025-12-03 11:22:51'),(19,25,2,'Switzerland',0,'2025-12-03 11:22:51'),(20,25,2,'Austria',0,'2025-12-03 11:22:51'),(21,25,3,'France',1,'2025-12-03 11:22:51'),(22,25,3,'Italy',0,'2025-12-03 11:22:51'),(23,25,3,'Spain',0,'2025-12-03 11:22:51'),(24,25,3,'Portugal',0,'2025-12-03 11:22:51'),(25,25,4,'France',1,'2025-12-03 11:22:51'),(26,25,4,'Belgium',0,'2025-12-03 11:22:51'),(27,25,4,'Netherlands',0,'2025-12-03 11:22:51'),(28,25,4,'Luxembourg',0,'2025-12-03 11:22:51'),(29,25,5,'France',1,'2025-12-03 11:22:51'),(30,25,5,'Germany',0,'2025-12-03 11:22:51'),(31,25,5,'Italy',0,'2025-12-03 11:22:51'),(32,25,5,'Spain',0,'2025-12-03 11:22:51'),(33,26,1,'France',1,'2025-12-03 15:08:25'),(34,26,1,'Belgium',0,'2025-12-03 15:08:25'),(35,26,1,'Germany',0,'2025-12-03 15:08:25'),(36,26,1,'Italy',0,'2025-12-03 15:08:25'),(37,26,2,'Germany',1,'2025-12-03 15:08:25'),(38,26,2,'Poland',0,'2025-12-03 15:08:25'),(39,26,2,'Czech Republic',0,'2025-12-03 15:08:25'),(40,26,2,'Austria',0,'2025-12-03 15:08:25'),(41,26,3,'United States',1,'2025-12-03 15:08:25'),(42,26,3,'Canada',0,'2025-12-03 15:08:25'),(43,26,3,'Mexico',0,'2025-12-03 15:08:25'),(44,26,3,'Cuba',0,'2025-12-03 15:08:25'),(45,27,1,'Egypt',1,'2025-12-03 16:12:57'),(46,27,1,'Turkey',0,'2025-12-03 16:12:57'),(47,27,1,'Greece',0,'2025-12-03 16:12:57'),(48,27,1,'Lebanon',0,'2025-12-03 16:12:57'),(49,27,2,'United States',1,'2025-12-03 16:12:57'),(50,27,2,'Canada',0,'2025-12-03 16:12:57'),(51,27,2,'Mexico',0,'2025-12-03 16:12:57'),(52,27,2,'Australia',0,'2025-12-03 16:12:57'),(53,27,3,'Germany',1,'2025-12-03 16:12:57'),(54,27,3,'Austria',0,'2025-12-03 16:12:57'),(55,27,3,'Switzerland',0,'2025-12-03 16:12:57'),(56,27,3,'Netherlands',0,'2025-12-03 16:12:57'),(57,27,4,'Monaco',1,'2025-12-03 16:12:57'),(58,27,4,'Italy',0,'2025-12-03 16:12:57'),(59,27,4,'France',0,'2025-12-03 16:12:57'),(60,27,4,'Spain',0,'2025-12-03 16:12:57'),(61,28,1,'Monaco',1,'2025-12-03 17:57:35'),(62,28,1,'Paris',0,'2025-12-03 17:57:35'),(63,28,1,'Roma',0,'2025-12-03 17:57:35'),(64,28,1,'Cairo',0,'2025-12-03 17:57:35'),(65,28,2,'France',1,'2025-12-03 17:57:35'),(66,28,2,'Monaco',0,'2025-12-03 17:57:35'),(67,28,2,'Berlin',0,'2025-12-03 17:57:35'),(68,28,2,'New York',0,'2025-12-03 17:57:35'),(69,28,3,'Germany',1,'2025-12-03 17:57:35'),(70,28,3,'London',0,'2025-12-03 17:57:35'),(71,28,3,'São Paulo',0,'2025-12-03 17:57:35'),(72,28,3,'Cairo',0,'2025-12-03 17:57:35'),(73,28,4,'Egypt',1,'2025-12-03 17:57:35'),(74,28,4,'Berlin',0,'2025-12-03 17:57:35'),(75,28,4,'Monaco',0,'2025-12-03 17:57:35'),(76,28,4,'New York',0,'2025-12-03 17:57:35'),(77,29,1,'Monaco',1,'2025-12-03 18:12:15'),(78,29,1,'Berlin',0,'2025-12-03 18:12:15'),(79,29,1,'Cairo',0,'2025-12-03 18:12:15'),(80,29,2,'Berlin',1,'2025-12-03 18:12:15'),(81,29,2,'Paris',0,'2025-12-03 18:12:15'),(82,29,2,'São Paulo',0,'2025-12-03 18:12:15'),(83,29,3,'Cairo',1,'2025-12-03 18:12:15'),(84,29,3,'Sydney',0,'2025-12-03 18:12:15'),(85,29,3,'New York',0,'2025-12-03 18:12:15'),(86,29,4,'Cairo',1,'2025-12-03 18:12:15'),(87,29,4,'São Paulo',0,'2025-12-03 18:12:15'),(88,29,4,'Monaco',0,'2025-12-03 18:12:15');
/*!40000 ALTER TABLE `case_travel_options` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03 18:28:22
