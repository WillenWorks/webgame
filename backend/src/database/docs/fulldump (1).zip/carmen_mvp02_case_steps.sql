-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: carmen_mvp02
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `case_steps`
--

DROP TABLE IF EXISTS `case_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_steps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `step_order` int NOT NULL,
  `from_location_id` int DEFAULT NULL,
  `to_location_id` int DEFAULT NULL,
  `step_type` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'clue',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `case_steps_ibfk_1` (`case_id`),
  KEY `case_steps_ibfk_2` (`from_location_id`),
  KEY `case_steps_ibfk_3` (`to_location_id`),
  CONSTRAINT `case_steps_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `case_steps_ibfk_2` FOREIGN KEY (`from_location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `case_steps_ibfk_3` FOREIGN KEY (`to_location_id`) REFERENCES `locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_steps`
--

LOCK TABLES `case_steps` WRITE;
/*!40000 ALTER TABLE `case_steps` DISABLE KEYS */;
INSERT INTO `case_steps` VALUES (1,1,1,NULL,3,'briefing','Você recebe um dossiê preliminar sobre Mira Caledonia e é enviado para London para investigar.','2025-11-29 19:57:18'),(2,1,2,3,3,'clue','Moradores locais relatam ter visto uma figura compatível com o perfil de Mira Caledonia circulando em áreas turísticas.','2025-11-29 19:57:18'),(3,3,1,NULL,1,'briefing','O agente recebe informações em um café elegante. Um garçom menciona que viu uma mulher com luvas de couro, como se estivesse escondendo algo. Ele também observa que ela estava tocando piano antes de sair apressada.','2025-11-29 21:11:29'),(4,3,2,NULL,2,'clue','Em uma galeria de arte, o agente encontra uma pintura com uma cifra clássica. Ao investigar, descobre que a arte foi comprada recentemente por uma mulher de cabelo preto que se destacou em eventos de criptografia.','2025-11-29 21:11:29'),(5,3,3,NULL,3,'transition','O agente segue as pistas até uma antiga biblioteca onde encontra uma mensagem codificada. O livro contém uma nota sobre um veículo escuro que foi visto nas proximidades de um evento de criptografia.','2025-11-29 21:11:29'),(6,3,4,NULL,5,'clue','Uma fonte confiável informa que Helena Morozov estava em um concerto recentemente. Ela é conhecida por quebrar cifras governamentais, o que levanta suspeitas sobre suas intenções.','2025-11-29 21:11:29'),(7,3,5,NULL,6,'briefing','O agente se encontra com um informante que menciona que Helena planeja uma fuga. Ele descreve um veículo escuro e uma mulher que sempre usa luvas, indicando que ela pode estar mais próxima do que se imagina.','2025-11-29 21:11:29'),(18,6,1,NULL,1,'briefing','No luxuoso auditório de Monaco, o agente recebe um comunicado sobre uma série de cifras encontradas em partituras de piano. As mensagens parecem estar relacionadas a um plano de roubo iminente.','2025-12-01 13:10:51'),(19,6,2,NULL,2,'clue','Em um café em Paris, o agente encontra um garçom que menciona ter visto uma mulher com cabelo negro usando uma luva de couro. Ele também menciona que ela estava interessada em peças de piano raras.','2025-12-01 13:10:51'),(20,6,3,NULL,3,'clue','Na Biblioteca Nacional de Londres, o agente descobre um livro sobre criptografia que menciona uma talentosa criptógrafa. O autor do livro é um amigo de Helena Morozov, destacando seu talento incomum.','2025-12-01 13:10:51'),(21,6,4,NULL,4,'transition','Depois de seguir as pistas, o agente se dirige a Roma, onde se ouve rumores de que uma mulher está tentando vender informações valiosas. A descrição coincide com a da mulher que estava em Paris.','2025-12-01 13:10:51'),(22,6,5,NULL,5,'clue','Em uma galeria de arte em Berlim, o agente encontra um quadro que retrata uma mulher tocando piano. Ao lado, há uma cifra que remete a um código que Helena é famosa por quebrar.','2025-12-01 13:10:51'),(23,7,1,NULL,1,'briefing','Você se encontra em um café próximo ao porto, onde ouviu rumores sobre um piloto que frequentemente pousa em locais não oficiais. As pessoas falam sobre um homem de cabelo ruivo e uma cicatriz no queixo, que é conhecido por suas escaladas em rochas.','2025-12-01 13:56:13'),(24,7,2,NULL,2,'clue','Na Torre Eiffel, um grupo de alpinistas compartilha histórias sobre um piloto que os ajudou a chegar a destinos inusitados. Um deles menciona que o piloto sempre prefere voar em seu próprio avião particular.','2025-12-01 13:56:13'),(25,7,3,NULL,4,'transition','Você viaja para Roma, onde encontra uma pista deixada em uma loja de equipamentos de escalada. Um recibo de compra revela que o piloto adquiriu recentemente um novo equipamento que é frequentemente usado em escaladas difíceis.','2025-12-01 13:56:13'),(26,7,4,NULL,5,'clue','Em Berlim, você descobre uma foto de um grupo em uma escalada, e entre eles está o homem com a cicatriz no queixo. Alguém menciona que ele tinha uma fama de ser um excelente piloto em suas aventuras.','2025-12-01 13:56:13'),(27,7,5,NULL,10,'clue','Na Austrália, você encontra um documento de imigração que apresenta uma lista de voos não registrados. O nome de um piloto com características marcantes aparece frequentemente nos registros.','2025-12-01 13:56:13'),(28,8,1,NULL,1,'briefing','No luxuoso cassino de Mônaco, o agente recebe informações sobre um roubo recente. Um jogador avistou um homem calmo e de luvas observando atentamente as câmeras de segurança, como se estivesse planejando algo.','2025-12-01 14:02:32'),(29,8,2,NULL,2,'clue','Em uma livraria de Paris, o agente encontra um livro sobre segurança em museus. Dentro, uma anotações em um canto mostram um padrão de movimento que parece se alinhar com os horários de jogos de xadrez em cafés locais.','2025-12-01 14:02:32'),(30,8,3,NULL,3,'transition','O agente se dirige a Londres, onde descobre que um carro sedã foi visto nas proximidades do museu na noite do roubo. A descrição do veículo combina com o de um consultor de segurança conhecido na área.','2025-12-01 14:02:32'),(31,8,4,NULL,4,'clue','Em Roma, um informante revela que um homem com cabelo grisalho foi visto em várias exposições de arte, sempre vestido de maneira formal e com luvas, como se tentasse não deixar rastros.','2025-12-01 14:02:32'),(32,8,5,NULL,5,'clue','Na capital alemã, o agente encontra uma pista sobre um torneio de xadrez que ocorreu na mesma época dos roubos. O vencedor é um conhecido consultor de segurança que frequentemente utiliza suas habilidades para explorar falhas.','2025-12-01 14:02:32'),(33,9,1,NULL,1,'briefing','O agente chega ao cassino de Monte Carlo, onde um grupo de hackers foi visto. Um segurança menciona uma mulher com cabelo castanho escuro que estava tirando fotos da arquitetura. Essa pode ser a primeira pista.','2025-12-01 14:58:11'),(34,9,2,NULL,2,'clue','Em uma galeria de arte, o agente encontra uma exposição de fotografias urbanas. Uma das fotos mostra um corvo pousado em uma motocicleta, o que pode indicar um gosto peculiar da artista.','2025-12-01 14:58:11'),(35,9,3,NULL,3,'transition','Em uma conferência sobre segurança de dados, o agente descobre que um dos palestrantes é uma analista de dados. Ao investigar, percebe que ela é frequentemente vista em eventos de tecnologia na cidade.','2025-12-01 14:58:11'),(36,9,4,NULL,4,'clue','Na Piazza Navona, o agente se depara com um grupo de motociclistas. Um deles tem uma tatuagem de corvo visível no pulso, o que pode estar ligado à mulher que ele está procurando.','2025-12-01 14:58:11'),(37,9,5,NULL,5,'briefing','O agente recebe informações de um informante sobre uma mulher que anda de moto e é conhecida por vazamentos de dados. O informante menciona que ela costuma fotografar lugares históricos.','2025-12-01 14:58:11'),(38,10,1,NULL,1,'briefing','No luxuoso cassino de Monaco, o agente recebe informações sobre uma venda de arte que ocorreu na calada da noite. Um informante menciona um misterioso vendedor que possui uma cicatriz perto da sobrancelha direita.','2025-12-01 14:58:19'),(39,10,2,NULL,2,'clue','Em uma galeria de arte em Paris, o agente encontra uma pintura que parece ser uma falsificação. O curador menciona que o autor era conhecido por suas jogadas de poker em alta stakes, sugerindo uma conexão com o mundo do jogo.','2025-12-01 14:58:19'),(40,10,3,NULL,3,'transition','O agente segue para Londres, onde descobre que um carro esportivo preto foi visto em uma transação suspeita. O veículo é associado a um conhecido negociador de arte.','2025-12-01 14:58:19'),(41,10,4,NULL,6,'clue','Em Nova York, o agente investiga um leilão clandestino e encontra documentos que indicam que o vendedor utiliza um nome falso, mas as assinaturas têm um padrão peculiar, revelando uma conexão com leilões anteriores.','2025-12-01 14:58:19'),(42,10,5,NULL,7,'clue','Em Tóquio, o agente é apresentado a um colecionador que menciona ter perdido uma obra de arte valiosa para um \'art dealer\' misterioso que se destaca por suas vendas em leilões ilegais.','2025-12-01 14:58:19'),(43,11,1,NULL,1,'briefing','O agente recebe informações sobre um roubo de dados em um banco local. O banco está preocupado com um possível insider, e a última vez que as câmeras mostraram atividade suspeita foi quando uma mulher de fones de ouvido entrou no prédio.','2025-12-01 14:58:30'),(44,11,2,NULL,2,'clue','Em um café em Paris, o agente encontra um grupo de gamers conversando sobre um torneio de retro videogames. Um deles menciona uma jogadora que sempre usa fones de ouvido e que era conhecida por suas habilidades em segurança digital.','2025-12-01 14:58:30'),(45,11,3,NULL,7,'transition','O agente viaja para Tóquio, onde descobre que Ayumi Kato trabalhou anteriormente em segurança de sistemas bancários. Uma ex-colega menciona que ela costumava se deslocar em uma scooter elétrica para ir ao trabalho.','2025-12-01 14:58:30'),(46,11,4,NULL,5,'clue','Em Berlim, o agente encontra um hacker que afirma ter visto Ayumi em um mercado de tecnologia, comprando equipamentos para melhorar sua configuração de segurança cibernética.','2025-12-01 14:58:30'),(47,11,5,NULL,3,'briefing','O agente se encontra com uma fonte em Londres que revela que Ayumi foi vista rondando perto de um banco, sempre com seus fones de ouvido, como se estivesse escutando algo importante.','2025-12-01 14:58:30');
/*!40000 ALTER TABLE `case_steps` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-02 16:19:09
