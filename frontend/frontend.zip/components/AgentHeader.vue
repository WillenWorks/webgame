<template>
  <header class="border-b border-slate-700 bg-slate-900/80 backdrop-blur">
    <div class="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.3em] text-sky-400">
          IGI // International GeoIntelligence Initiative
        </p>
        <h1 class="text-2xl font-bold text-slate-50">
          Operação Monaco
        </h1>
        <p class="text-xs text-slate-400">
          Painel do Agente · MVP de Treinamento
        </p>
      </div>

      <div class="text-right">
        <p class="text-xs text-slate-400 uppercase tracking-wide">
          Cargo atual
        </p>
        <p class="text-sm font-semibold text-emerald-300">
          Analista Cadete
        </p>
      </div>
    </div>
  </header>
</template>

<script setup>
// Nenhuma lógica necessária por enquanto
</script>
