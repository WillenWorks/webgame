<template>
  <NuxtPage />
</template>